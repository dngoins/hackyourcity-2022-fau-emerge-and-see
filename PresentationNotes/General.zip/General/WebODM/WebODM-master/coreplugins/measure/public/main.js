PluginsAPI.Map.willAddControls([
    	'measure/build/app.js',
    	'measure/build/app.css'
	], function(args, App){
	new App(args.map);
});

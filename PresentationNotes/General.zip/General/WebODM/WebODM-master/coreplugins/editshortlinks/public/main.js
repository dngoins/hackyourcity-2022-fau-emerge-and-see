PluginsAPI.SharePopup.addLinkControl([
        'editshortlinks/build/SLControls.js',
        'editshortlinks/build/SLControls.css'
    ],function(args, SLControls){
        return SLControls;
    }
);
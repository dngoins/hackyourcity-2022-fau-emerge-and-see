PluginsAPI.Dashboard.addNewTaskPanelItem([
    'lightning/build/CostEstimateItem.js',
    'lightning/build/CostEstimateItem.css',
],function(args, CostEstimateItem){
    return CostEstimateItem;
});
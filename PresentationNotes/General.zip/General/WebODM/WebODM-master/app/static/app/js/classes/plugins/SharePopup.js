export default {
  namespace: "SharePopup",

  endpoints: [
    "addLinkControl",
  ]
};


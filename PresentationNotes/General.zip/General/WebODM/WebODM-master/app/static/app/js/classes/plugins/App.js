export default {
  namespace: "App",

  endpoints: [
	"ready"
  ]
};


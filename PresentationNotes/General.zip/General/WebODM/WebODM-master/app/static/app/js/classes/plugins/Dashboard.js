export default {
  namespace: "Dashboard",

  endpoints: [
    "addTaskActionButton",
    "addNewTaskPanelItem",
    "addNewTaskButton"
  ]
};


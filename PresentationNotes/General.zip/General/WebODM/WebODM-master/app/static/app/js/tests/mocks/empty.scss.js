/* Empty stylesheet

Currently we don't transpile SCSS files when
testing with Jest. We might want to change
this in the future if we start doing snapshot
testing */

export default {};
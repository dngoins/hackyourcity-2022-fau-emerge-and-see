// Auto-generated with extract_plugin_manifest_strings.py, do not edit!

from django.utils.translation import gettext as _
_("Detect changes between two different tasks in the same project.")
_("Import images from external sources directly")
_("Compute, preview and export contours from DEMs")
_("Display program version, memory and disk space usage statistics")
_("Calculate and draw an elevation map based on a task's DEMs")
_("Add a fullscreen button to the 2D map view")
_("Sync accounts from webodm.net")
_("Compute volume, area and length measurements on Leaflet")
_("A plugin to upload orthophotos to OpenAerialMap")
_("A plugin to add a button for quickly opening OpenStreetMap's iD editor and setup a TMS basemap.")
_("A plugin to create GCP files from images")
_("A plugin to create GCP files from images")
_("Create short links when sharing task URLs")
_("Create editable short links when sharing task URLs")
_("Integrate WebODM with DroneDB: import images and share results")
